@echo -off
cls
echo ====================================================================
echo   SWIFFER ZERO-DRIVER FIRMWARE SEAL  --  PROFILE: ghost-857
echo   TARGET: EAC  (SECURE BOOT ON AFTER FLASH)
echo ====================================================================
echo.
# Locate the USB or ESP filesystem containing swiffer_boot.efi or AMIDEEFIx64.efi
for %m in fs0 fs1 fs2 fs3 fs4 fs5 fs6
  if exist %m:\EFI\Swiffer\swiffer_boot.efi then
    %m:
    \EFI\Swiffer\swiffer_boot.efi
  endif
  if exist %m:\swiffer_boot.efi then
    %m:
    \swiffer_boot.efi
  endif
  if exist %m:\AMIDEEFIx64.efi then
    %m:
    goto FLASH_DMI
  endif
endfor
goto NIC_STEP

:FLASH_DMI
echo [*] Flashing SMBIOS Type 0 / Type 1 / Type 2 / Type 3 into NVRAM...
AMIDEEFIx64.efi /IVN "American Megatrends Inc."
AMIDEEFIx64.efi /IV "F12"
AMIDEEFIx64.efi /SM "Gigabyte"
AMIDEEFIx64.efi /SU 590186830E1A4E7591B063583353FD43
AMIDEEFIx64.efi /SS "9UB16MWH1YP0"
AMIDEEFIx64.efi /BM "Gigabyte"
AMIDEEFIx64.efi /BS "SN9E5B6FD22994"
AMIDEEFIx64.efi /CM "Gigabyte"
AMIDEEFIx64.efi /CS "GIG-DCED7EE1"
echo [+] SMBIOS NVRAM flash complete.

:NIC_STEP
echo [*] Per-adapter MAC plan (NIC EEPROM / Station Address):
echo     NIC #1: A0:36:BC:21:9D:3A -> A0:36:BC:18:9A:02 (A036BC189A02)
# If using Intel EEUPDATE64e.efi:   EEUPDATE64e.efi /NIC=1 /MAC=A036BC189A02
# If using Realtek PG8168.efi:      PG8168.efi /efuse /nodeid A036BC189A02
echo     NIC #2: 00:50:56:C0:00:01 -> 00:50:56:0A:3C:93 (0050560A3C93)
# If using Intel EEUPDATE64e.efi:   EEUPDATE64e.efi /NIC=2 /MAC=0050560A3C93
# If using Realtek PG8168.efi:      PG8168.efi /efuse /nodeid 0050560A3C93
echo     NIC #3: 00:50:56:C0:00:08 -> 00:50:56:0E:D6:7F (0050560ED67F)
# If using Intel EEUPDATE64e.efi:   EEUPDATE64e.efi /NIC=3 /MAC=0050560ED67F
# If using Realtek PG8168.efi:      PG8168.efi /efuse /nodeid 0050560ED67F
echo.
echo [+] Done. Reboot into BIOS, enable Secure Boot + RAID/VMD, then boot Windows.
