# Zero-Runtime-Footprint Runbook — `ghost-857` (`eac`)

This bundle configures the machine with **zero custom `.sys` drivers loaded in RAM**, **Secure Boot ON**, and **`testsigning OFF`**, eliminating all kernel module, `\Driver`, `\Device`, and certificate tells.

## 1. Coherent Identity Values (`ghost-857`)

| Surface | Profile Value | Mechanism |
|---|---|---|
| `smbios.board_vendor` | `Gigabyte` | UEFI DMI Flash (`startup.nsh`) + Registry Seal |
| `smbios.bios_vendor` | `American Megatrends Inc.` (`F12`) | UEFI DMI Flash (`startup.nsh`) + Registry Seal |
| `smbios.system_uuid` | `59018683-0E1A-4E75-91B0-63583353FD43` | UEFI DMI Flash (`/SU`) + `SMBiosData` Seal |
| `smbios.board_serial` | `SN9E5B6FD22994` | UEFI DMI Flash (`/BS`) + `SMBiosData` Seal |
| `smbios.chassis_serial` | `GIG-DCED7EE1` | UEFI DMI Flash (`/CS`) + `SMBiosData` Seal |
| `smbios.system_serial` | `9UB16MWH1YP0` | UEFI DMI Flash (`/SS`) + `SMBiosData` Seal |
| `windows.machine_guid` | `B2E9E0CD-53CC-4116-A524-06CFB7D709CD` | `swiffer seal` (with SQM & HwProfileGuid) |
| `network.hostname` | `quiet-ledger-16` | `swiffer seal` (all 4 ComputerName/Tcpip keys) |
| `storage.disk_signature` | `9BB455D9` | `swiffer seal --boot` (MBR `0x1B8` + `MountedDevices`) |
| `storage.gpt_disk_guid` | `F9176DDE-37D1-4E14-938B-F4C3726B3C33` | `swiffer seal --boot` (Primary + Backup GPT + CRC32) |
| `storage.volume_serial` | `5EC0233F` | `swiffer seal --boot` (VBR boot sector) |

### Per-Adapter MAC Plan
| Adapter | Original MAC | Spoofed MAC (`NetworkAddress`) |
|---|---|---|
| NIC #1 | `A0:36:BC:21:9D:3A` | `A0:36:BC:18:9A:02` (`A036BC189A02`) |
| NIC #2 | `00:50:56:C0:00:01` | `00:50:56:0A:3C:93` (`0050560A3C93`) |
| NIC #3 | `00:50:56:C0:00:08` | `00:50:56:0E:D6:7F` (`0050560ED67F`) |

### Per-Drive Serial Plan
| Drive | Original Serial | Spoofed Serial | Spoofed Model |
|---|---|---|---|
| Disk #1 | `E823_8FA6_BF53_0001_001B_448B_4BD8_CA7F.` | `WD-WRIQSP6CZIW9S` | `Western Digital` |

---

## 2. Step-by-Step Execution

1. **Suspend BitLocker (if enabled):**
   ```powershell
   Suspend-BitLocker -MountPoint "C:" -RebootCount 2
   ```
2. **Flash SMBIOS in UEFI Shell (Permanent):**
   * Format a USB drive as **FAT32**.
   * Copy `EFI/Boot/bootx64.efi` (EDK2 UEFI Shell), `AMIDEEFIx64.efi`, and this folder's `startup.nsh` to the USB root.
   * Boot from the USB drive; `startup.nsh` automatically flashes `/SU`, `/BS`, `/CS`, `/SS`, `/SM`, and `/BM`.
3. **Configure Storage & TPM in BIOS Setup:**
   * Enable **Intel VMD** or **AMD RAIDXpert2** (wrapping the NVMe/SATA drive in a single-drive Volume/RAID0 array so the inbox WHQL RAID driver answers hardware serial queries).
   * Run **Clear Security Device / Clear TPM** in BIOS (rotates the fTPM / PTT Endorsement Key seed), and ensure **Secure Boot is Enabled**.
4. **Run Permanent Seal in Windows (Elevated PowerShell):**
   ```powershell
   python scripts/dev.py seal --profile data/profiles/ghost-857.json --boot --yes
   ```
   This permanently writes all registry GUIDs, all 4 hostnames, `SMBiosData`, per-adapter NIC `NetworkAddress` values, MBR `0x1B8`, `MountedDevices`, Primary + Backup GPT `DiskGUID`, and the partition VBR `volume_serial`.
5. **Reboot & Verify:**
   ```powershell
   python scripts/dev.py verify --profile data/profiles/ghost-857.json
   python scripts/dev.py coherence --profile data/profiles/ghost-857.json
   python scripts/dev.py exposure
   ```

---

## 3. Pre-Boot Layer (what makes the hardware surfaces stick)

Windows refuses a raw write to any disk that has mounted volumes, so the
SMBIOS tables and the boot-sector identity are re-sealed by a small UEFI
application that runs before the OS starts:

| Artifact | Location on the EFI System Partition |
|---|---|
| Payload | `\EFI\Swiffer\swiffer_boot.efi` |
| SMBIOS manifest | `\EFI\Swiffer\manifest.bin` |
| Boot-sector values | `\EFI\Swiffer\boot-sector.txt` |

`swiffer seal` registers it as a `BOOTAPP` entry and places it first in the
display order. The Windows loader entry is never modified, so if the payload
fails the firmware falls through to Windows.

Requirements: UEFI firmware, Secure Boot **off** (an unsigned payload will not
run under it), and one reboot.

Check or undo:

```powershell
python scripts/dev.py boot-entry status
python scripts/dev.py boot-entry remove
```

Removing the entry stops the pre-boot re-seal. The Windows-side seal (registry,
hostname, MAC, trace cleanup) is independent and stays in place.
