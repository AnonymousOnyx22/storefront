@echo off
setlocal
echo ====================================================================
echo   SWIFFER BARE-METAL WINDOWS SEAL  --  PROFILE: ghost-915
echo ====================================================================
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] Please run this script as Administrator.
    exit /b 1
)

if exist AMIDEWINx64.exe (
    echo [*] Running AMIDEWINx64.exe...
    AMIDEWINx64.exe /IVN "LENOVO"
    AMIDEWINx64.exe /IV "N2VET58W (1.58)"
    AMIDEWINx64.exe /SM "Lenovo"
    AMIDEWINx64.exe /SU 964475FFFB024BD9B48F301742E69D34
    AMIDEWINx64.exe /SS "E2L52TOZTJ82"
    AMIDEWINx64.exe /BM "Lenovo"
    AMIDEWINx64.exe /BS "81JPOC05"
    AMIDEWINx64.exe /CM "Lenovo"
    AMIDEWINx64.exe /CS "YZA9KHKG"
) else (
    echo [i] AMIDEWINx64.exe not in current folder; use startup.nsh from UEFI Shell for locked BIOSes.
)

echo [*] Applying permanent Swiffer registry + boot-sector + NIC seal...
call "%~dp0..\..\..\swiffer.bat" seal --profile data/profiles/ghost-915.json --boot --yes

echo [*] Restarting physical network adapters to apply NetworkAddress registry MACs...
powershell -NoProfile -Command "Get-NetAdapter -Physical | Restart-NetAdapter -Confirm:$false"
ipconfig /flushdns >nul 2>&1
arp -d * >nul 2>&1
echo     NIC #1 active MAC target: A0:36:BC:94:BE:F7
echo     NIC #2 active MAC target: 00:50:56:CC:78:B4
echo     NIC #3 active MAC target: 00:50:56:FA:3B:35
echo [+] Complete. Reboot the machine, then run:
echo     python -m swiffer verify --profile data/profiles/ghost-915.json
echo     python -m swiffer coherence --profile data/profiles/ghost-915.json
echo     python -m swiffer exposure
endlocal
