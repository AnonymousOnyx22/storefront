@echo off
setlocal
echo ====================================================================
echo   SWIFFER BARE-METAL WINDOWS SEAL  --  PROFILE: ghost-857
echo ====================================================================
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] Please run this script as Administrator.
    exit /b 1
)

if exist AMIDEWINx64.exe (
    echo [*] Running AMIDEWINx64.exe...
    AMIDEWINx64.exe /IVN "American Megatrends Inc."
    AMIDEWINx64.exe /IV "F12"
    AMIDEWINx64.exe /SM "Gigabyte"
    AMIDEWINx64.exe /SU 590186830E1A4E7591B063583353FD43
    AMIDEWINx64.exe /SS "9UB16MWH1YP0"
    AMIDEWINx64.exe /BM "Gigabyte"
    AMIDEWINx64.exe /BS "SN9E5B6FD22994"
    AMIDEWINx64.exe /CM "Gigabyte"
    AMIDEWINx64.exe /CS "GIG-DCED7EE1"
) else (
    echo [i] AMIDEWINx64.exe not in current folder; use startup.nsh from UEFI Shell for locked BIOSes.
)

echo [*] Applying permanent Swiffer registry + boot-sector + NIC seal...
call "%~dp0..\..\..\swiffer.bat" seal --profile data/profiles/ghost-857.json --boot --yes

echo [*] Restarting physical network adapters to apply NetworkAddress registry MACs...
powershell -NoProfile -Command "Get-NetAdapter -Physical | Restart-NetAdapter -Confirm:$false"
ipconfig /flushdns >nul 2>&1
arp -d * >nul 2>&1
echo     NIC #1 active MAC target: A0:36:BC:18:9A:02
echo     NIC #2 active MAC target: 00:50:56:0A:3C:93
echo     NIC #3 active MAC target: 00:50:56:0E:D6:7F
echo [+] Complete. Reboot the machine, then run:
echo     python -m swiffer verify --profile data/profiles/ghost-857.json
echo     python -m swiffer coherence --profile data/profiles/ghost-857.json
echo     python -m swiffer exposure
endlocal
