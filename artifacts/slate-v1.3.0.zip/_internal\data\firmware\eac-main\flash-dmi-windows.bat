@echo off
setlocal
echo ====================================================================
echo   SWIFFER BARE-METAL WINDOWS SEAL  --  PROFILE: eac-main
echo ====================================================================
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] Please run this script as Administrator.
    exit /b 1
)

if exist AMIDEWINx64.exe (
    echo [*] Running AMIDEWINx64.exe...
    AMIDEWINx64.exe /IVN "American Megatrends Inc."
    AMIDEWINx64.exe /IV "3.05"
    AMIDEWINx64.exe /SM "ASUS"
    AMIDEWINx64.exe /SP "PRIME B550M-K"
    AMIDEWINx64.exe /SU 481CBEAB632A4B97949FFC74AFB2DC04
    AMIDEWINx64.exe /SS "R0RQDTJVXOS8"
    AMIDEWINx64.exe /BM "ASUS"
    AMIDEWINx64.exe /BP "PRIME B550M-K"
    AMIDEWINx64.exe /BS "3767303339"
    AMIDEWINx64.exe /CM "ASUS"
    AMIDEWINx64.exe /CS "2534068760"
) else (
    echo [i] AMIDEWINx64.exe not in current folder; use startup.nsh from UEFI Shell for locked BIOSes.
)

echo [*] Applying permanent Swiffer registry + boot-sector + NIC seal...
call "%~dp0..\..\..\swiffer.bat" seal --profile data/profiles/eac-main.json --boot --yes

echo [*] Restarting physical network adapters to apply NetworkAddress registry MACs...
powershell -NoProfile -Command "Get-NetAdapter -Physical | Restart-NetAdapter -Confirm:$false"
ipconfig /flushdns >nul 2>&1
arp -d * >nul 2>&1
echo     NIC #1 active MAC target: A0:36:BC:B2:FA:94
echo     NIC #2 active MAC target: 00:50:56:DC:40:FF
echo     NIC #3 active MAC target: 00:50:56:22:71:66
echo [+] Complete. Reboot the machine, then run:
echo     python -m swiffer verify --profile data/profiles/eac-main.json
echo     python -m swiffer coherence --profile data/profiles/eac-main.json
echo     python -m swiffer exposure
endlocal
