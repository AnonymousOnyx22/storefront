# Zero-Runtime-Footprint Runbook — `ghost-915` (`eac`)

This bundle configures the machine with **zero custom `.sys` drivers loaded in RAM**, **Secure Boot ON**, and **`testsigning OFF`**, eliminating all kernel module, `\Driver`, `\Device`, and certificate tells.

## 1. Coherent Identity Values (`ghost-915`)

| Surface | Profile Value | Mechanism |
|---|---|---|
| `smbios.board_vendor` | `Lenovo` | UEFI DMI Flash (`startup.nsh`) + Registry Seal |
| `smbios.bios_vendor` | `LENOVO` (`N2VET58W (1.58)`) | UEFI DMI Flash (`startup.nsh`) + Registry Seal |
| `smbios.system_uuid` | `964475FF-FB02-4BD9-B48F-301742E69D34` | UEFI DMI Flash (`/SU`) + `SMBiosData` Seal |
| `smbios.board_serial` | `81JPOC05` | UEFI DMI Flash (`/BS`) + `SMBiosData` Seal |
| `smbios.chassis_serial` | `YZA9KHKG` | UEFI DMI Flash (`/CS`) + `SMBiosData` Seal |
| `smbios.system_serial` | `E2L52TOZTJ82` | UEFI DMI Flash (`/SS`) + `SMBiosData` Seal |
| `windows.machine_guid` | `3D9442BB-6CBF-465C-BEC4-8BC296531B3E` | `swiffer seal` (with SQM & HwProfileGuid) |
| `network.hostname` | `hollow-silo-29` | `swiffer seal` (all 4 ComputerName/Tcpip keys) |
| `storage.disk_signature` | `619F64E0` | `swiffer seal --boot` (MBR `0x1B8` + `MountedDevices`) |
| `storage.gpt_disk_guid` | `0363C066-5D89-494A-A3C1-97B264CC349D` | `swiffer seal --boot` (Primary + Backup GPT + CRC32) |
| `storage.volume_serial` | `3D76BBEA` | `swiffer seal --boot` (VBR boot sector) |

### Per-Adapter MAC Plan
| Adapter | Original MAC | Spoofed MAC (`NetworkAddress`) |
|---|---|---|
| NIC #1 | `A0:36:BC:21:9D:3A` | `A0:36:BC:94:BE:F7` (`A036BC94BEF7`) |
| NIC #2 | `00:50:56:C0:00:01` | `00:50:56:CC:78:B4` (`005056CC78B4`) |
| NIC #3 | `00:50:56:C0:00:08` | `00:50:56:FA:3B:35` (`005056FA3B35`) |

### Per-Drive Serial Plan
| Drive | Original Serial | Spoofed Serial | Spoofed Model |
|---|---|---|---|
| Disk #1 | `E823_8FA6_BF53_0001_001B_448B_4BD8_CA7F.` | `UTIZD6EALX` | `Kingston` |

---

## 2. Step-by-Step Execution

1. **Suspend BitLocker (if enabled):**
   ```powershell
   Suspend-BitLocker -MountPoint "C:" -RebootCount 2
   ```
2. **Flash SMBIOS in UEFI Shell (Permanent):**
   * Format a USB drive as **FAT32**.
   * Copy `EFI/Boot/bootx64.efi` (EDK2 UEFI Shell), `AMIDEEFIx64.efi`, and this folder's `startup.nsh` to the USB root.
   * Boot from the USB drive; `startup.nsh` automatically flashes `/SU`, `/BS`, `/CS`, `/SS`, `/SM`, and `/BM`.
3. **Configure Storage & TPM in BIOS Setup:**
   * Enable **Intel VMD** or **AMD RAIDXpert2** (wrapping the NVMe/SATA drive in a single-drive Volume/RAID0 array so the inbox WHQL RAID driver answers hardware serial queries).
   * Run **Clear Security Device / Clear TPM** in BIOS (rotates the fTPM / PTT Endorsement Key seed), and ensure **Secure Boot is Enabled**.
4. **Run Permanent Seal in Windows (Elevated PowerShell):**
   ```powershell
   python scripts/dev.py seal --profile data/profiles/ghost-915.json --boot --yes
   ```
   This permanently writes all registry GUIDs, all 4 hostnames, `SMBiosData`, per-adapter NIC `NetworkAddress` values, MBR `0x1B8`, `MountedDevices`, Primary + Backup GPT `DiskGUID`, and the partition VBR `volume_serial`.
5. **Reboot & Verify:**
   ```powershell
   python scripts/dev.py verify --profile data/profiles/ghost-915.json
   python scripts/dev.py coherence --profile data/profiles/ghost-915.json
   python scripts/dev.py exposure
   ```

---

## 3. Pre-Boot Layer (what makes the hardware surfaces stick)

Windows refuses a raw write to any disk that has mounted volumes, so the
SMBIOS tables and the boot-sector identity are re-sealed by a small UEFI
application that runs before the OS starts:

| Artifact | Location on the EFI System Partition |
|---|---|
| Payload | `\EFI\Swiffer\swiffer_boot.efi` |
| SMBIOS manifest | `\EFI\Swiffer\manifest.bin` |
| Boot-sector values | `\EFI\Swiffer\boot-sector.txt` |

`swiffer seal` registers it as a `BOOTAPP` entry and places it first in the
display order. The Windows loader entry is never modified, so if the payload
fails the firmware falls through to Windows.

Requirements: UEFI firmware, Secure Boot **off** (an unsigned payload will not
run under it), and one reboot.

Check or undo:

```powershell
python scripts/dev.py boot-entry status
python scripts/dev.py boot-entry remove
```

Removing the entry stops the pre-boot re-seal. The Windows-side seal (registry,
hostname, MAC, trace cleanup) is independent and stays in place.
