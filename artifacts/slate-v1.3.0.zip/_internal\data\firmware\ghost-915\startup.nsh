@echo -off
cls
echo ====================================================================
echo   SWIFFER ZERO-DRIVER FIRMWARE SEAL  --  PROFILE: ghost-915
echo   TARGET: EAC  (SECURE BOOT ON AFTER FLASH)
echo ====================================================================
echo.
# Locate the USB or ESP filesystem containing swiffer_boot.efi or AMIDEEFIx64.efi
for %m in fs0 fs1 fs2 fs3 fs4 fs5 fs6
  if exist %m:\EFI\Swiffer\swiffer_boot.efi then
    %m:
    \EFI\Swiffer\swiffer_boot.efi
  endif
  if exist %m:\swiffer_boot.efi then
    %m:
    \swiffer_boot.efi
  endif
  if exist %m:\AMIDEEFIx64.efi then
    %m:
    goto FLASH_DMI
  endif
endfor
goto NIC_STEP

:FLASH_DMI
echo [*] Flashing SMBIOS Type 0 / Type 1 / Type 2 / Type 3 into NVRAM...
AMIDEEFIx64.efi /IVN "LENOVO"
AMIDEEFIx64.efi /IV "N2VET58W (1.58)"
AMIDEEFIx64.efi /SM "Lenovo"
AMIDEEFIx64.efi /SU 964475FFFB024BD9B48F301742E69D34
AMIDEEFIx64.efi /SS "E2L52TOZTJ82"
AMIDEEFIx64.efi /BM "Lenovo"
AMIDEEFIx64.efi /BS "81JPOC05"
AMIDEEFIx64.efi /CM "Lenovo"
AMIDEEFIx64.efi /CS "YZA9KHKG"
echo [+] SMBIOS NVRAM flash complete.

:NIC_STEP
echo [*] Per-adapter MAC plan (NIC EEPROM / Station Address):
echo     NIC #1: A0:36:BC:21:9D:3A -> A0:36:BC:94:BE:F7 (A036BC94BEF7)
# If using Intel EEUPDATE64e.efi:   EEUPDATE64e.efi /NIC=1 /MAC=A036BC94BEF7
# If using Realtek PG8168.efi:      PG8168.efi /efuse /nodeid A036BC94BEF7
echo     NIC #2: 00:50:56:C0:00:01 -> 00:50:56:CC:78:B4 (005056CC78B4)
# If using Intel EEUPDATE64e.efi:   EEUPDATE64e.efi /NIC=2 /MAC=005056CC78B4
# If using Realtek PG8168.efi:      PG8168.efi /efuse /nodeid 005056CC78B4
echo     NIC #3: 00:50:56:C0:00:08 -> 00:50:56:FA:3B:35 (005056FA3B35)
# If using Intel EEUPDATE64e.efi:   EEUPDATE64e.efi /NIC=3 /MAC=005056FA3B35
# If using Realtek PG8168.efi:      PG8168.efi /efuse /nodeid 005056FA3B35
echo.
echo [+] Done. Reboot into BIOS, enable Secure Boot + RAID/VMD, then boot Windows.
