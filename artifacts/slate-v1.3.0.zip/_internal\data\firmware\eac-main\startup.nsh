@echo -off
cls
echo ====================================================================
echo   SWIFFER ZERO-DRIVER FIRMWARE SEAL  --  PROFILE: eac-main
echo   TARGET: EAC  (SECURE BOOT ON AFTER FLASH)
echo ====================================================================
echo.
# Locate the USB or ESP filesystem containing bootrec.efi or AMIDEEFIx64.efi
for %m in fs0 fs1 fs2 fs3 fs4 fs5 fs6
  if exist %m:\EFI\Microsoft\Recovery\bootrec.efi then
    %m:
    \EFI\Microsoft\Recovery\bootrec.efi
  endif
  if exist %m:\bootrec.efi then
    %m:
    \bootrec.efi
  endif
  if exist %m:\AMIDEEFIx64.efi then
    %m:
    goto FLASH_DMI
  endif
endfor
goto NIC_STEP

:FLASH_DMI
echo [*] Flashing SMBIOS Type 0 / Type 1 / Type 2 / Type 3 into NVRAM...
AMIDEEFIx64.efi /IVN "American Megatrends Inc."
AMIDEEFIx64.efi /IV "3.05"
AMIDEEFIx64.efi /SM "ASUS"
AMIDEEFIx64.efi /SP "PRIME B550M-K"
AMIDEEFIx64.efi /SU 481CBEAB632A4B97949FFC74AFB2DC04
AMIDEEFIx64.efi /SS "R0RQDTJVXOS8"
AMIDEEFIx64.efi /BM "ASUS"
AMIDEEFIx64.efi /BP "PRIME B550M-K"
AMIDEEFIx64.efi /BS "3767303339"
AMIDEEFIx64.efi /CM "ASUS"
AMIDEEFIx64.efi /CS "2534068760"
echo [+] SMBIOS NVRAM flash complete.

:NIC_STEP
echo [*] Per-adapter MAC plan (NIC EEPROM / Station Address):
echo     NIC #1: A0:36:BC:21:9D:3A -> A0:36:BC:B2:FA:94 (A036BCB2FA94)
# If using Intel EEUPDATE64e.efi:   EEUPDATE64e.efi /NIC=1 /MAC=A036BCB2FA94
# If using Realtek PG8168.efi:      PG8168.efi /efuse /nodeid A036BCB2FA94
echo     NIC #2: 00:50:56:C0:00:01 -> 00:50:56:DC:40:FF (005056DC40FF)
# If using Intel EEUPDATE64e.efi:   EEUPDATE64e.efi /NIC=2 /MAC=005056DC40FF
# If using Realtek PG8168.efi:      PG8168.efi /efuse /nodeid 005056DC40FF
echo     NIC #3: 00:50:56:C0:00:08 -> 00:50:56:22:71:66 (005056227166)
# If using Intel EEUPDATE64e.efi:   EEUPDATE64e.efi /NIC=3 /MAC=005056227166
# If using Realtek PG8168.efi:      PG8168.efi /efuse /nodeid 005056227166
echo.
echo [+] Done. Reboot into BIOS, enable Secure Boot + RAID/VMD, then boot Windows.
